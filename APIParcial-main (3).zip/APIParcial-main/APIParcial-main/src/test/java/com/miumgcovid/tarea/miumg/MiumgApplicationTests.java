package com.miumgcovid.tarea.miumg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiumgApplicationTests {

	@Test
	void contextLoads() {
	}

}
