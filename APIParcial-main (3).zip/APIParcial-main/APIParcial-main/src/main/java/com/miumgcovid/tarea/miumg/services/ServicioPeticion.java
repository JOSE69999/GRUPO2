package com.miumgcovid.tarea.miumg.services;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.miumgcovid.tarea.miumg.repositories.RepositorioReporte;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.miumgcovid.tarea.miumg.models.RegionAPI;
import com.miumgcovid.tarea.miumg.models.ProvinciaAPI;
import com.miumgcovid.tarea.miumg.models.ReporteAPI;
import com.miumgcovid.tarea.miumg.repositories.repositorioRegion;
import com.miumgcovid.tarea.miumg.repositories.RepositorioProvincia;

@Service
public class ServicioPeticion {

    // URLs de las APIs
    final String regionesURL = "https://covid-19-statistics.p.rapidapi.com/regions";
    final String provinciasURL = "https://covid-19-statistics.p.rapidapi.com/provinces";
    final String reporteURL = "https://covid-19-statistics.p.rapidapi.com/reports?iso=GTM&date=2022-04-16";

    // Instancia RestTemplate
    final RestTemplate request = new RestTemplate();
    private HttpHeaders header = new HttpHeaders();

    // Inyección de dependencias para los repositorios
    @Autowired
    private repositorioRegion repositorioRegion;

    @Autowired
    private RepositorioProvincia repositorioProvincia;

    @Autowired
    private RepositorioReporte repositorioReporte; // Se cambió de repositorioRegion a RepositorioReporte

    // Constructor por defecto
    public ServicioPeticion() {
    }

    // Método para obtener las regiones
    public void buscaRegiones() {

        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");

        // Crear la entidad con la cabecera
        HttpEntity<Void> requestEntity = new HttpEntity<>(this.header);

        // Hacer la petición a la API
        ResponseEntity<String> response = this.request.exchange(this.regionesURL, HttpMethod.GET, requestEntity, String.class);

        // Convertir el cuerpo de la respuesta a un JSON
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});


            Object data = responseMap.get("data");

            // Verificar que 'data' sea una lista
            if (data instanceof List<?>) {
                List<?> arrayData = (List<?>) data;
                // Verificar que los elementos sean del tipo esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> regionsList = (List<Map<String, Object>>) arrayData;

                    // Guardar cada región en la base de datos
                    for (Map<String, Object> dato : regionsList) {
                        String iso = (String) dato.get("iso");
                        String name = (String) dato.get("name");

                        if (iso != null && !iso.isBlank()) {
                            RegionAPI region = new RegionAPI();
                            region.setIso(iso);
                            region.setName(name != null ? name : "");
                            repositorioRegion.save(region);
                        } else {
                            System.out.println("Se encontró una región con ISO vacío o nulo. No se guardará: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }

    // Método para obtener las provincias
    public void buscaProvincias() {

        String URLFinal = this.provinciasURL + "?iso=GTM";


        this.header = new HttpHeaders();
        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");


        Map<String, Object> data = new HashMap<>();
        data.put("iso", "GTM");
        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(data, this.header);

        // Hacer la petición a la API
        ResponseEntity<String> response = this.request.exchange(URLFinal, HttpMethod.GET, requestEntity, String.class);

        // Convertir el cuerpo de la respuesta a un JSON
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});

            // Obtener la lista de provincias
            Object dataProv = responseMap.get("data");

            // Verificar que 'data' sea una lista antes de hacer el cast
            if (dataProv instanceof List<?>) {
                List<?> arrayData = (List<?>) dataProv;
                // Verificar que los elementos sean del tipo esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> provincesList = (List<Map<String, Object>>) arrayData;

                    // Guardar cada provincia en la base de datos
                    for (Map<String, Object> dato : provincesList) {
                        String iso = (String) dato.get("iso");
                        String name = (String) dato.get("name");

                        if (iso != null && !iso.isBlank()) {
                            ProvinciaAPI provincia = new ProvinciaAPI();
                            provincia.setIso(iso);
                            provincia.setName(name != null ? name : "");
                            repositorioProvincia.save(provincia);
                        } else {
                            System.out.println("Se encontró una provincia con ISO vacío o nulo. No se guardará: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }

    // Método para obtener el reporte
    public void buscaReporte() {

        this.header.setContentType(MediaType.APPLICATION_JSON);
        this.header.set("X-RapidAPI-Key", "2505eda46amshc60713983b5e807p1da25ajsn36febcbf4a71");
        this.header.set("X-RapidAPI-Host", "covid-19-statistics.p.rapidapi.com");

        // Crear la entidad con la cabecera
        HttpEntity<Void> requestEntity = new HttpEntity<>(this.header);

        // Hacer la petición a la API
        ResponseEntity<String> response = this.request.exchange(this.reporteURL, HttpMethod.GET, requestEntity, String.class);

        // Convertir el cuerpo de la respuesta a un JSON
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> responseMap = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {});

            // Obtener los datos del reporte
            Object dataReport = responseMap.get("data");

            // Verificar que 'data' sea una lista antes de hacer el cast
            if (dataReport instanceof List<?>) {
                List<?> arrayData = (List<?>) dataReport;
                // Verificar que los elementos sean del tipo esperado
                if (!arrayData.isEmpty() && arrayData.get(0) instanceof Map<?, ?>) {
                    List<Map<String, Object>> reportList = (List<Map<String, Object>>) arrayData;

                    // Guardar cada reporte en la base de datos
                    for (Map<String, Object> dato : reportList) {
                        String date = (String) dato.get("date");
                        int confirmed = (Integer) dato.get("confirmed");
                        int deaths = (Integer) dato.get("deaths");
                        int recovered = (Integer) dato.get("recovered");

                        if (date != null && !date.isBlank()) {
                            ReporteAPI reporte = new ReporteAPI();
                            reporte.setDate(date);
                            reporte.setConfirmed(confirmed);
                            reporte.setDeaths(deaths);
                            reporte.setRecovered(recovered);
                            repositorioReporte.save(reporte);  // Se usa la instancia correcta aquí
                        } else {
                            System.out.println("Se encontró un reporte con fecha vacía o nula. No se guardará: " + dato);
                        }
                    }
                } else {
                    System.out.println("Los datos no tienen el formato esperado.");
                }
            } else {
                System.out.println("El tipo de 'data' no es una lista.");
            }

        } catch (JsonProcessingException e) {
            System.err.println("Error al procesar el JSON: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
        }
    }
}