package com.miumgcovid.tarea.miumg.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miumgcovid.tarea.miumg.models.ReporteAPI;

@Repository
public interface RepositorioReporte extends JpaRepository<ReporteAPI, String> {

}
